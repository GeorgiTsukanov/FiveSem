﻿namespace PI_31_2_Tsukanov_NN.NeuroNet
{
    partial class FormMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.labelOutput = new System.Windows.Forms.Label();
            this.labelProbability = new System.Windows.Forms.Label();
            this.buttonRecognize = new System.Windows.Forms.Button();
            this.buttonTraining = new System.Windows.Forms.Button();
            this.numericUpDown_NecessaryOutput = new System.Windows.Forms.NumericUpDown();
            this.button_SaveTrainSample = new System.Windows.Forms.Button();
            this.button_Save_Test_Sample = new System.Windows.Forms.Button();
            this.chart_Eavr = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonTesting = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_NecessaryOutput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Eavr)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(9, 10);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 32);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(44, 10);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 32);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(78, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 32);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(9, 47);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(30, 32);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(44, 47);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 32);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(78, 47);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 32);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(9, 84);
            this.button7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 32);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(44, 84);
            this.button8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(30, 32);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(78, 84);
            this.button9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 32);
            this.button9.TabIndex = 8;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(9, 122);
            this.button10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 32);
            this.button10.TabIndex = 9;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(44, 122);
            this.button11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(30, 32);
            this.button11.TabIndex = 10;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(78, 122);
            this.button12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 32);
            this.button12.TabIndex = 11;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(9, 159);
            this.button13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(30, 32);
            this.button13.TabIndex = 12;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(44, 159);
            this.button14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(30, 32);
            this.button14.TabIndex = 13;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(78, 159);
            this.button15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 32);
            this.button15.TabIndex = 14;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.Changing_State_Pixel_Button_Click);
            // 
            // labelOutput
            // 
            this.labelOutput.AutoSize = true;
            this.labelOutput.Location = new System.Drawing.Point(112, 10);
            this.labelOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelOutput.Name = "labelOutput";
            this.labelOutput.Size = new System.Drawing.Size(38, 13);
            this.labelOutput.TabIndex = 15;
            this.labelOutput.Text = "выход";
            // 
            // labelProbability
            // 
            this.labelProbability.AutoSize = true;
            this.labelProbability.Location = new System.Drawing.Point(152, 10);
            this.labelProbability.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelProbability.Name = "labelProbability";
            this.labelProbability.Size = new System.Drawing.Size(71, 13);
            this.labelProbability.TabIndex = 16;
            this.labelProbability.Text = "вероятность";
            // 
            // buttonRecognize
            // 
            this.buttonRecognize.Location = new System.Drawing.Point(115, 47);
            this.buttonRecognize.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonRecognize.Name = "buttonRecognize";
            this.buttonRecognize.Size = new System.Drawing.Size(104, 32);
            this.buttonRecognize.TabIndex = 17;
            this.buttonRecognize.Text = "предсказать";
            this.buttonRecognize.UseVisualStyleBackColor = true;
            this.buttonRecognize.Click += new System.EventHandler(this.buttonRecognize_Click);
            // 
            // buttonTraining
            // 
            this.buttonTraining.Location = new System.Drawing.Point(115, 84);
            this.buttonTraining.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonTraining.Name = "buttonTraining";
            this.buttonTraining.Size = new System.Drawing.Size(104, 32);
            this.buttonTraining.TabIndex = 18;
            this.buttonTraining.Text = "обучить";
            this.buttonTraining.UseVisualStyleBackColor = true;
            this.buttonTraining.Click += new System.EventHandler(this.buttonTraining_Click);
            // 
            // numericUpDown_NecessaryOutput
            // 
            this.numericUpDown_NecessaryOutput.Location = new System.Drawing.Point(9, 197);
            this.numericUpDown_NecessaryOutput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numericUpDown_NecessaryOutput.Name = "numericUpDown_NecessaryOutput";
            this.numericUpDown_NecessaryOutput.Size = new System.Drawing.Size(99, 20);
            this.numericUpDown_NecessaryOutput.TabIndex = 19;
            // 
            // button_SaveTrainSample
            // 
            this.button_SaveTrainSample.Location = new System.Drawing.Point(9, 219);
            this.button_SaveTrainSample.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_SaveTrainSample.Name = "button_SaveTrainSample";
            this.button_SaveTrainSample.Size = new System.Drawing.Size(99, 43);
            this.button_SaveTrainSample.TabIndex = 20;
            this.button_SaveTrainSample.Text = "сохранить тренировочный пример";
            this.button_SaveTrainSample.UseVisualStyleBackColor = true;
            this.button_SaveTrainSample.Click += new System.EventHandler(this.button_SaveTrainSample_Click);
            // 
            // button_Save_Test_Sample
            // 
            this.button_Save_Test_Sample.Location = new System.Drawing.Point(9, 267);
            this.button_Save_Test_Sample.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_Save_Test_Sample.Name = "button_Save_Test_Sample";
            this.button_Save_Test_Sample.Size = new System.Drawing.Size(99, 43);
            this.button_Save_Test_Sample.TabIndex = 21;
            this.button_Save_Test_Sample.Text = "сохранить тестовый пример";
            this.button_Save_Test_Sample.UseVisualStyleBackColor = true;
            // 
            // chart_Eavr
            // 
            chartArea1.Name = "ChartArea1";
            this.chart_Eavr.ChartAreas.Add(chartArea1);
            this.chart_Eavr.Location = new System.Drawing.Point(224, 47);
            this.chart_Eavr.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.chart_Eavr.Name = "chart_Eavr";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Name = "Series1";
            this.chart_Eavr.Series.Add(series1);
            this.chart_Eavr.Size = new System.Drawing.Size(368, 263);
            this.chart_Eavr.TabIndex = 22;
            this.chart_Eavr.Text = "chart1";
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            title1.Name = "Title1";
            title1.Text = "График средних энергий ошибок";
            this.chart_Eavr.Titles.Add(title1);
            // 
            // buttonTesting
            // 
            this.buttonTesting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonTesting.Location = new System.Drawing.Point(116, 120);
            this.buttonTesting.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTesting.Name = "buttonTesting";
            this.buttonTesting.Size = new System.Drawing.Size(104, 32);
            this.buttonTesting.TabIndex = 23;
            this.buttonTesting.Text = "тестировать";
            this.buttonTesting.UseVisualStyleBackColor = true;
            this.buttonTesting.Click += new System.EventHandler(this.buttonTesting_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.buttonTesting);
            this.Controls.Add(this.chart_Eavr);
            this.Controls.Add(this.button_Save_Test_Sample);
            this.Controls.Add(this.button_SaveTrainSample);
            this.Controls.Add(this.numericUpDown_NecessaryOutput);
            this.Controls.Add(this.buttonTraining);
            this.Controls.Add(this.buttonRecognize);
            this.Controls.Add(this.labelProbability);
            this.Controls.Add(this.labelOutput);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FormMain";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_NecessaryOutput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Eavr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label labelOutput;
        private System.Windows.Forms.Label labelProbability;
        private System.Windows.Forms.Button buttonRecognize;
        private System.Windows.Forms.Button buttonTraining;
        private System.Windows.Forms.NumericUpDown numericUpDown_NecessaryOutput;
        private System.Windows.Forms.Button button_SaveTrainSample;
        private System.Windows.Forms.Button button_Save_Test_Sample;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_Eavr;
        private System.Windows.Forms.Button buttonTesting;
    }
}

