document.addEventListener('DOMContentLoaded', function() {
    // Элементы DOM для таблицы
    const radioButtons = document.querySelectorAll('input[name="sort-type"]');
    const tableBody = document.querySelector('#bank-rates-table tbody');
    const sortableHeaders = document.querySelectorAll('.sortable');
    
    // Элементы DOM для калькулятора
    const operationRadios = document.querySelectorAll('input[name="operation"]');
    const bankSelect = document.getElementById('bank-select');
    const amountInput = document.getElementById('amount-rub');
    const resultInput = document.getElementById('amount-usd');
    const amountLabel = document.getElementById('amount-label');
    const resultLabel = document.getElementById('amount-usd-label');
    const rateInfo = document.getElementById('rate-info');
    
    // Данные таблицы
    let tableData = Array.from(tableBody.querySelectorAll('tr')).map(row => ({
        element: row,
        bank: row.dataset.bank,
        buyRate: parseFloat(row.dataset.buyRate), // Банк покупает (человек продает)
        sellRate: parseFloat(row.dataset.sellRate), // Банк продает (человек покупает)
        date: row.cells[3].textContent
    }));
    
    // Текущее состояние сортировки
    let currentSort = {
        type: 'buy', // 'buy' (покупаю USD) или 'sell' (продаю USD)
        direction: 'asc' // 'asc' или 'desc'
    };
    
    // Функция сортировки таблицы
    function sortTable() {
        let sortBy, sortDirection;
        
        // Определяем по какому полю и в каком направлении сортировать
        if (currentSort.type === 'buy') {
            // Покупаю USD - сортируем по продаже (банк продает) по возрастанию (лучшая цена для покупателя)
            sortBy = 'sellRate';
            sortDirection = 'asc';
        } else {
            // Продаю USD - сортируем по покупке (банк покупает) по убыванию (лучшая цена для продавца)
            sortBy = 'buyRate';
            sortDirection = 'desc';
        }
        
        tableData.sort((a, b) => {
            if (sortDirection === 'asc') {
                return a[sortBy] - b[sortBy];
            } else {
                return b[sortBy] - a[sortBy];
            }
        });
        
        // Очистка и перезаполнение таблицы
        tableBody.innerHTML = '';
        tableData.forEach(item => {
            tableBody.appendChild(item.element);
        });
        
        // Обновление индикаторов сортировки
        updateSortIndicators();
    }
    
    // Функция обновления индикаторов сортировки
    function updateSortIndicators() {
        sortableHeaders.forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
            
            const sortType = header.dataset.sort;
            
            if (currentSort.type === 'buy' && sortType === 'sell-rate') {
                // Покупаю USD - сортировка по продаже по возрастанию
                header.classList.add('sort-asc');
            } else if (currentSort.type === 'sell' && sortType === 'buy-rate') {
                // Продаю USD - сортировка по покупке по убыванию
                header.classList.add('sort-desc');
            }
        });
    }
})
