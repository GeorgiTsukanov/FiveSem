﻿using System;
using System.IO;
using System.Windows.Forms;

namespace PI_31_2_Tsukanov_Snejok.NeuroNet
{
    abstract class Layer
    {
        protected string name_Layer;
        string pathDirWeigths;
        string pathFileWeights;
        protected int numofneurons;
        protected int numofprevneurons;
        protected const double learningrate = 0.060;
        protected const double momentum = 0.050d;
        protected double[,] lastdeltaweights;
        protected Neuron[] neurons;

        public Neuron[] Neurons { get => neurons; set => neurons = value; }

        public double[] Data
        {
            set
            {
                for (int i = 0; i < numofneurons; i++)
                {
                    Neurons[i].Activator(value);
                }
            }
        }

        protected Layer(int non, int nonp, NeuronType nt, string nm_Layer)
        {
            numofneurons = non;
            numofprevneurons = nonp;
            Neurons = new Neuron[non];
            name_Layer = nm_Layer;
            pathDirWeigths = AppDomain.CurrentDomain.BaseDirectory + "memory\\";
            pathFileWeights = pathDirWeigths + name_Layer + "_memory.csv";

            lastdeltaweights = new double[non, nonp + 1];
            double[,] Weights;

            if(File.Exists(pathFileWeights)){
                Weights = WeightInitialize(MemoryMode.GET, pathFileWeights);
            }
            else
            {
                Directory.CreateDirectory(pathDirWeigths);
                Weights = WeightInitialize(MemoryMode.INIT, pathFileWeights);
            }

            for (int i=0; i<non; i++)
            {
                double[] tmp_weights = new double[nonp + 1];
                for (int j =0; j < nonp +1; j++)
                {
                    tmp_weights[j] = Weights[i, j];
                }
                Neurons[i] = new Neuron(tmp_weights, nt);
            }

        }

        public double[,] WeightInitialize(MemoryMode mm, string path)
        {
            string tmpStr;
            string[] tmpStrWeights;
            double[,] weights = new double[numofneurons, numofprevneurons + 1];

            switch (mm)
            {
                case MemoryMode.GET:
                    tmpStrWeights = File.ReadAllLines(path);
                    string[] memory_element;
                    for (int i= 0; i < numofneurons; i++)
                    {

                    }
                    break;
                case MemoryMode.SET:
                    break;
                case MemoryMode.INIT:
                    break;
                default:
                    break;
            }
        }
    }
}