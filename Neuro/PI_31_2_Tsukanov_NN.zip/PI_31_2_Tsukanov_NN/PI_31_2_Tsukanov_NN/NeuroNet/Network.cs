﻿
using System;
using System.Linq;

namespace PI_31_2_Tsukanov_NN.NeuroNet
{
    class Network
    {
        // Архитектура: 15-71-35-10
        private InputLayer inputLayer = null;
        private HiddenLayer hidden_layer1 = new HiddenLayer(71, 15, NeuronType.Hidden, nameof(hidden_layer1));
        private HiddenLayer hidden_layer2 = new HiddenLayer(35, 71, NeuronType.Hidden, nameof(hidden_layer2));
        private OutputLayer output_layer = new OutputLayer(10, 35, NeuronType.Output, nameof(output_layer));

        private double[] fact = new double[10];
        private double[] e_error_avr;
        public double[] accuracy; // точность

        public double[] Fact { get => fact; }
        public double[] Accuracy { get => accuracy; }
        public double[] E_error_avr { get => e_error_avr; set => e_error_avr = value; }

        public Network() { }

        public void ForwardPass(Network net, double[] netInput, NetworkMode nm)
        {
            net.hidden_layer1.Data = netInput;
            net.hidden_layer1.Recognize(null, net.hidden_layer2, nm);
            net.hidden_layer2.Recognize(null, net.output_layer, nm);
            net.output_layer.Recognize(net, null, nm);
        }

        public void Train(Network net, NetworkMode nm)
        {
            net.inputLayer = new InputLayer(NetworkMode.Train);
            int epoches = 10;
            double tmpSumError;  // временная переменная суммы ошибок
            double[] errors; // вектор сигнала ошибки выходного слоя
            double[] temp_gsums1; // вектор градиента 1-го скрытого слоя
            double[] temp_gsums2; // вектор градиента 2-го скрытого слоя

            e_error_avr = new double[epoches];
            accuracy = new double[epoches]; // точность

            for (int k = 0; k < epoches; k++) 
            {
                e_error_avr[k] = 0; // значение средней ошибки

                int correct_predictions = 0;

                net.inputLayer.Shuffling_Array_Rows(net.inputLayer.Trainset);
                for (int i = 0; i < net.inputLayer.Trainset.GetLength(0); i++)
                {
                    double[] tmpTrain = new double[15];
                    for (int j = 0; j < tmpTrain.Length; j++)
                        tmpTrain[j] = net.inputLayer.Trainset[i, j + 1];
                    ForwardPass(net, tmpTrain, nm);

                    // вычисление ошибки по итерации
                    tmpSumError = 0;
                    errors = new double[net.fact.Length];
                    for (int x = 0; x < errors.Length; x++)
                    {
                        if (x == net.inputLayer.Trainset[i, 0])
                            errors[x] = 1.0 - net.fact[x]; // 0.0 - net.fact[x];
                        else
                            errors[x] = -net.fact[x];

                        tmpSumError += errors[x] * errors[x] / 2;
                    }
                    e_error_avr[k] += tmpSumError / errors.Length; // суммарное значение энергии ошибки

                    int predicted = net.fact.ToList().IndexOf(net.fact.Max());
                    int actual = (int)net.inputLayer.Trainset[i, 0];
                    if (predicted == actual) correct_predictions++;

                    temp_gsums2 = net.output_layer.BackwardPass(errors, nm);
                    temp_gsums1 = net.hidden_layer2.BackwardPass(temp_gsums2, nm);
                    net.hidden_layer1.BackwardPass(temp_gsums1, nm);
                }
                e_error_avr[k] /= net.inputLayer.Trainset.GetLength(0);
                accuracy[k] = (double)correct_predictions / net.inputLayer.Trainset.GetLength(0);
            }
            net.inputLayer = null; //обнуление (уборка) входного слоя
            net.hidden_layer1.WeightInitialize(MemoryMode.SET, nameof(hidden_layer1) + "memory.csv");
            net.hidden_layer2.WeightInitialize(MemoryMode.SET, nameof(hidden_layer2) + "memory.csv");
            net.output_layer.WeightInitialize(MemoryMode.SET, nameof(output_layer) + "memory.csv");
        }

        public void Test(Network net, NetworkMode nm)
        {
            net.inputLayer = new InputLayer(NetworkMode.Test);
            int epoches = 10;
            double tmpSumError;
            double[] errors;
            double[] temp_gsums1;
            double[] temp_gsums2;

            e_error_avr = new double[epoches];
            accuracy = new double[epoches]; // точность

            for (int k = 0; k < epoches; k++)
            {
                e_error_avr[k] = 0;

                int correct_predictions = 0;

                net.inputLayer.Shuffling_Array_Rows(net.inputLayer.Testset);
                for (int i = 0; i < net.inputLayer.Testset.GetLength(0); i++)
                {
                    double[] tmpTest = new double[15];
                    for (int j = 0; j < tmpTest.Length; j++)
                        tmpTest[j] = net.inputLayer.Testset[i, j + 1];
                    ForwardPass(net, tmpTest, nm);

                    tmpSumError = 0;
                    errors = new double[net.fact.Length];
                    /*
                    for (int x = 0; x < errors.Length; x++)
                    {
                        if (x == net.inputLayer.Testset[i, 0])
                            errors[x] = 1.0 - net.fact[x];
                        else
                            errors[x] = -net.fact[x];

                        tmpSumError += errors[x] * errors[x] / 2;
                    }
                    */

                    for (int x = 0; x < errors.Length; x++)
                    {
                        double target = (x == net.inputLayer.Testset[i, 0]) ? 1.0 : 0.0;
                        errors[x] = target - net.fact[x];
                        tmpSumError += Math.Abs(errors[x]) * Math.Abs(errors[x]) / 2;
                    }

                    e_error_avr[k] += tmpSumError / errors.Length;

                    int predicted = net.fact.ToList().IndexOf(net.fact.Max());
                    int actual = (int)net.inputLayer.Testset[i, 0];
                    if (predicted == actual) correct_predictions++;
                }
                e_error_avr[k] /= net.inputLayer.Testset.GetLength(0);
                accuracy[k] = (double)correct_predictions / net.inputLayer.Testset.GetLength(0);
            }
            net.inputLayer = null;
        }
    }
}