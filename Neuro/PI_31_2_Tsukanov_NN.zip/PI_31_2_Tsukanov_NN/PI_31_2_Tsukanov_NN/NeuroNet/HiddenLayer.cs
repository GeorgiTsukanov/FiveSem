﻿using System;
using System.Drawing.Text;

namespace PI_31_2_Tsukanov_NN.NeuroNet
{
    class HiddenLayer : Layer
    {
        private double[] dropOutMask;
        public HiddenLayer(int non, int nonp, NeuronType nt, string type) :
            base(non, nonp, nt, type)
        {}

        public double[] GenerateDropoutMask(int size, double dropoutRate, bool scale = true)
        {
            if (dropoutRate < 0f || dropoutRate >= 1f)
                throw new ArgumentException("dropoutRate должен быть в диапазоне [0.0, 1.0)", nameof(dropoutRate));

            double[] mask = new double[size];

            // коэффициент масштабирования 
            double scaleFactor = scale ? 1.0d / (1.0d - dropoutRate) : 1.0d;

            Random rand = new Random();
            for (int i = 0; i < size; i++)
            {
                double randomValue = rand.NextDouble();
                if (randomValue < dropoutRate)
                {
                    mask[i] = 0.0d;
                }
                else
                {
                    mask[i] = scaleFactor;
                }
            }

            return mask;
        }

        public override void Recognize(Network net, Layer nextLayer, NetworkMode nm)
        {
            double[] hidden_out = new double[numofneurons];
            if (nm == NetworkMode.Dropout)
            {
                dropOutMask = GenerateDropoutMask(numofneurons, 0.25d);
                for (int i = 0; i < numofneurons; i++)
                    hidden_out[i] = neurons[i].Output * dropOutMask[i];
            }
            else
            {
                for (int i = 0; i < numofneurons; i++)
                    hidden_out[i] = neurons[i].Output;
            }
            nextLayer.Data = hidden_out;// передача выходного сигнала на вход следующего слоя
        }

        
        public override double[] BackwardPass(double[] gr_sums, NetworkMode nm)
        {
            //применение маски
            if (nm == NetworkMode.Dropout)
            {
                for (int i =0; i<numofneurons; i++)
                {
                    gr_sums[i] *= dropOutMask[i];
                }
            }

            double[] gr_sum = new double[numofprevneurons];
            for (int j = 0; j < numofprevneurons; j++)
            {
                double sum = 0;
                for (int k = 0; k < numofneurons; k++)
                    sum += neurons[k].Weights[j+1] * neurons[k].Derivative * gr_sums[k];
                gr_sum[j] = sum;
            }
            for (int i = 0; i < numofneurons; i++)
                for (int n = 0; n < numofprevneurons + 1; n++)
                {
                    if (nm == NetworkMode.Dropout && gr_sums[i] == 0 && n != 0) // Пропускаем обновление веса, если нейрон выключен
                        continue;

                    double deltaw;
                    if (n == 0)
                        deltaw = momentum * lastdeltaweights[i, 0] + learningrate * neurons[i].Derivative * gr_sums[i];
                    else
                        deltaw = momentum * lastdeltaweights[i, n] + learningrate * neurons[i].Inputs[n - 1] * neurons[i].Derivative * gr_sums[i];
                    lastdeltaweights[i, n] = deltaw;
                    neurons[i].Weights[n] += deltaw;
                }
            return gr_sum;
        }
        
    }
}
